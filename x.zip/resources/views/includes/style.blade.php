<link rel="stylesheet" href="{{ url('assets/css/style.css') }}">
<link rel="stylesheet" href="{{ url('assets/css/widgets.css') }}">
<link rel="stylesheet" href="{{ url('assets/css/color.css') }}">
<link rel="stylesheet" href="{{ url('assets/css/responsive.css') }}">