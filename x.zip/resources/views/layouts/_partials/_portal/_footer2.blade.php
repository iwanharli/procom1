<footer id="footer-10" class="pt-100 footer">
    <div class="container text-center">
        <div class="row justify-content-center">
            <div class="col-xl-10">


                <!-- FOOTER LINKS -->
                <div class="footer-links">
                    <ul class="foo-links clearfix">
                        <li>
                            <p><a href="demo-1.html">Home</a></p>
                        </li>
                        <li>
                            <p><a href="careers.html">Careers</a></p>
                        </li>
                        <li>
                            <p><a href="blog-listing.html">Blog</a></p>
                        </li>
                        <li>
                            <p><a href="contacts.html">Contact Us</a></p>
                        </li>
                    </ul>
                </div>


                <!-- FOOTER SOCIALS -->
                <ul class="bottom-footer-socials ico-25">
                    <li><a href="#"><span class="flaticon-facebook"></span></a></li>
                    <li><a href="#"><span class="flaticon-twitter-1"></span></a></li>
                    <li><a href="#"><span class="flaticon-instagram"></span></a></li>
                    <li><a href="#"><span class="flaticon-linkedin-logo"></span></a></li>
                    <li><a href="#"><span class="flaticon-dribbble"></span></a></li>
                </ul>


            </div>
        </div> <!-- End row -->
    </div> <!-- End container -->
</footer>
