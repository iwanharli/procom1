<section id="banner-1" class="banner-section pt-100">
    <div class="container">


        <!-- BANNER-1 WRAPPER -->
        <div class="banner-1-wrapper ba--02 bg--fixed r-16 block--shadow">
            <div class="banner-overlay">
                <div class="row d-flex align-items-center">


                    <!-- BANNER-1 TEXT -->
                    <div class="col-md-8 col-lg-7">
                        <div class="banner-1-txt">

                            <!-- Title -->
                            <h4 class="h4-md">Hubungi Kami</h4>

                            <!-- Text -->
                            <p class="p-md">Hubungi Kami untuk Informasi Lebih Lanjut tentang Layanan Pengembangan Software dan Keamanan IT.</p>

                            <!-- Button -->
                            <a href="mailto:contact@intishineutama.com" class="btn btn-sm r-06 btn--theme hover--theme" data-bs-toggle="modal"
                                data-bs-target="#modal-2">EMAIL : contact@intishineutama.com
                            </a>

                        </div>
                    </div>
                    <!-- END BANNER-1 TEXT -->


                </div> <!-- End row -->
            </div> <!-- End banner overlay -->
        </div> <!-- END BANNER-1 WRAPPER -->


    </div> <!-- End container -->
</section>
